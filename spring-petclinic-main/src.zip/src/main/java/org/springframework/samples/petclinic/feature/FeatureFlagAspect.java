package org.springframework.samples.petclinic.feature;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

@Aspect
@Component
public class FeatureFlagAspect {

    @Around("@annotation(featureEnabled)")
    public Object around(ProceedingJoinPoint pjp, FeatureEnabled featureEnabled) throws Throwable {
        String flag = featureEnabled.value();
        FeatureFlagEvaluator evaluator = SpringContext.getBean(FeatureFlagEvaluator.class);
        if (!evaluator.isEnabled(flag)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Feature '" + flag + "' is disabled");
        }
        return pjp.proceed();
    }

}
