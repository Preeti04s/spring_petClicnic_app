package org.springframework.samples.petclinic.feature;

public enum FlagType {
    BOOLEAN,
    WHITELIST,
    BLACKLIST,
    PERCENTAGE,
    GLOBAL_DISABLE
}
